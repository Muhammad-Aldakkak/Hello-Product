this is the master branch of Hello Product Graduate Project at FCI-CU in 2017 
Team : 
Seif Mostafa , Ahmed Al Shaar , Mohamed Ahmed Fouad Al Dakkak , Ghassan Jandali Rifai


Shortly : way to make products able to introduce themselves.

long story :
this project's target within market field and he use technology as his gun .
around such product , our project - Hello Product - takes his seat and let his eyes up the product to can see , 
as the customer need , 
he can see 360 degree if the customer feels excited about his product ,
180 degree if the product is old version or something like that, 
or just 90, maybe his back to the wall or customer budget pb.

the project mission after he gets the vision around the product to do his work and give the orders to the motor to let him go to 
the chosen person he specify from the shots cameras gave it to him.

Prototype is finished and you can reach website through https://helloproductblog.wordpress.com/ 
but Hello Product trip is not finished yet..

the project's last mission to make the product introduce himself using one of the following available methods till now :
sound , so the customer can record the ads as sound files to be played by speakers .
text , customer can write his ads to be displayed on lcd.
flayer , using robot arm the project will make the product introduce himself through flayer.
 the end.
 
there are some future plans in project sections :
presentation : hologram , AI interactions .. etc
other links for doc. will be added as soon as finish.
Thanks!
